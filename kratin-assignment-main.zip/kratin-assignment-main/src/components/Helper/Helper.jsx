import React from 'react'

const Helper = () => {
    return (
        <div className='sticky top-0 bg-green-500 shadow-md  w-full p-4 text-center -z-20'>
            <p>@chetan6780</p>
        </div>
    )
}

export default Helper