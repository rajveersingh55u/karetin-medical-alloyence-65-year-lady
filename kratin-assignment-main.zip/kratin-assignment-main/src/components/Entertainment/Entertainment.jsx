import React from 'react'

const Entertainment = () => {
  return (
    <div>Entertainment</div>
  )
}

export default Entertainment